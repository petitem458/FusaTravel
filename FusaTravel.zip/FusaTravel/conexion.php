<?php
$host = "localhost";
$user = "root";     // usuario por defecto en XAMPP
$pass = "";         // contraseña por defecto en XAMPP
$database = "turismo_fusa";  // nombre de tu base de datos (ya creada en phpMyAdmin)

$conn = new mysqli($host, $user, $pass, $database);

if ($conn->connect_error) {
    die("❌ Error de conexión: " . $conn->connect_error);
}
?>
