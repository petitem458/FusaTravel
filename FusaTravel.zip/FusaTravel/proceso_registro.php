<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include "conexion.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre     = trim($_POST['nombre']);
    $apellido   = trim($_POST['apellido']);
    $correo     = trim($_POST['correo']);
    $telefono   = trim($_POST['telefono']);
    $contrasena = $_POST['contrasena'];

    if (empty($nombre) || empty($apellido) || empty($correo) || empty($contrasena)) {
        die("❌ Todos los campos obligatorios deben llenarse. <a href='registro.php'>Volver</a>");
    }

    $hash = password_hash($contrasena, PASSWORD_DEFAULT);
    $rol_id = 1; // Turista por defecto

    $sql = "INSERT INTO usuarios (nombre, apellido, correo, telefono, contrasena, rol_id) 
            VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die("❌ Error en la consulta: " . $conn->error);
    }

    $stmt->bind_param("sssssi", $nombre, $apellido, $correo, $telefono, $hash, $rol_id);

    if ($stmt->execute()) {
        echo "✅ Registro exitoso. <a href='login.php'>Inicia sesión aquí</a>";
    } else {
        echo "❌ Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
} else {
    echo "❌ Acceso no válido.";
}
?>
