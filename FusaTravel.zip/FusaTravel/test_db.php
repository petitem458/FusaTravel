<?php
include "conexion.php";
echo "✅ Conexión exitosa a la base de datos: " . $database;
?>
