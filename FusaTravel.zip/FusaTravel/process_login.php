<?php
session_start();
include "conexion.php";

$correo     = $_POST['correo'];
$contrasena = $_POST['contrasena'];

$sql = "SELECT u.id, u.nombre, u.apellido, u.contrasena, r.nombre AS rol
        FROM usuarios u
        JOIN roles r ON u.rol_id = r.id
        WHERE u.correo = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $correo);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if ($user && password_verify($contrasena, $user['contrasena'])) {
    // Guardar sesión
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['nombre']  = $user['nombre'];
    $_SESSION['apellido'] = $user['apellido'];
    $_SESSION['rol']     = $user['rol'];

    // Redirigir según rol
    if ($user['rol'] === 'Administrador') {
        header("Location: admin_panel.php");
    } elseif ($user['rol'] === 'Desarrollador') {
        header("Location: dev_panel.php");
    } else {
        header("Location: index.php");
    }
    exit;
} else {
    echo "❌ Usuario o contraseña incorrectos. <a href='login.php'>Volver</a>";
}
