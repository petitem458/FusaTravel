<?php
// Mostrar errores (solo mientras pruebas)
error_reporting(E_ALL);
ini_set('display_errors', 1);

include "conexion.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Registro - FusaTravel</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Bootstrap & Custom Styles -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet">
</head>
<body>
    <div class="container-fluid bg-registration py-5" style="margin: 90px 0;">
        <div class="container py-5">
            <div class="row align-items-center">
                <div class="col-lg-5">
                    <div class="card border-0">
                        <div class="card-header bg-primary text-center p-4">
                            <h1 class="text-white m-0">Crear cuenta</h1>
                        </div>
                        <div class="card-body rounded-bottom bg-white p-5">
                            <!-- 🔹 Formulario -->
                            <form action="process_registro.php" method="post">
                                <div class="form-group">
                                    <input type="text" name="nombre" class="form-control p-4" placeholder="Tu nombre" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" name="apellido" class="form-control p-4" placeholder="Tus apellidos" required>
                                </div>
                                <div class="form-group">
                                    <input type="email" name="correo" class="form-control p-4" placeholder="Tu correo" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" name="telefono" class="form-control p-4" placeholder="Tu teléfono">
                                </div>
                                <div class="form-group">
                                    <input type="password" name="contrasena" class="form-control p-4" placeholder="Contraseña" required>
                                </div>
                                <div>
                                    <button class="btn btn-primary btn-block py-3" type="submit">Registrarme</button>
                                </div>
                            </form>
                            <p class="mt-3">¿Ya tienes cuenta? <a href="login.php">Inicia sesión</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
