<?php
session_start();
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'Administrador') {
    die("❌ Acceso denegado. Solo administradores.");
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel del Administrador - FusaTravel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <!-- Encabezado -->
    <nav class="navbar navbar-dark bg-dark">
        <div class="container-fluid">
            <span class="navbar-brand mb-0 h1">Panel de Administración</span>
            <span class="text-white">👤 <?php echo $_SESSION['nombre']; ?></span>
            <a href="logout.php" class="btn btn-outline-light btn-sm">Cerrar sesión</a>
        </div>
    </nav>

    <div class="container-fluid">
        <div class="row">
            <!-- Menú lateral -->
            <div class="col-md-2 bg-light vh-100 p-3">
                <h5>Menú</h5>
                <ul class="nav flex-column">
                    <li class="nav-item"><a href="admin_panel.php" class="nav-link">🏠 Inicio</a></li>
                    <li class="nav-item"><a href="lugares_admin.php" class="nav-link">📍 Gestionar lugares</a></li>
                    <li class="nav-item"><a href="usuarios_admin.php" class="nav-link">👥 Ver usuarios</a></li>
                </ul>
            </div>

            <!-- Contenido principal -->
            <div class="col-md-10 p-4">
                <h2>Bienvenido al Panel de Administración</h2>
                <p>Aquí podrás gestionar los destinos turísticos y ver los usuarios registrados.</p>

                <!-- Tarjetas de ejemplo -->
                <div class="row">
                    <div class="col-md-4">
                        <div class="card text-center">
                            <div class="card-body">
                                <h5 class="card-title">📍 Lugares</h5>
                                <p class="card-text">Agrega, edita o elimina destinos turísticos.</p>
                                <a href="lugares_admin.php" class="btn btn-primary">Gestionar</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="card text-center">
                            <div class="card-body">
                                <h5 class="card-title">👥 Usuarios</h5>
                                <p class="card-text">Ver lista de usuarios registrados.</p>
                                <a href="usuarios_admin.php" class="btn btn-primary">Ver</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="card text-center">
                            <div class="card-body">
                                <h5 class="card-title">⚙️ Configuración</h5>
                                <p class="card-text">Opciones generales del sistema.</p>
                                <a href="#" class="btn btn-secondary">Configurar</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Fin tarjetas -->
            </div>
        </div>
    </div>
</body>
</html>
