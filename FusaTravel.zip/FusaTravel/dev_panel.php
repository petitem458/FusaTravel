<?php
session_start();
include "conexion.php";

// Verificar que el usuario esté logueado y sea Desarrollador
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'Desarrollador') {
    die("❌ Acceso denegado. Solo el Desarrollador puede ver esta página.");
}

// Si se envía el formulario para cambiar rol
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['usuario_id'], $_POST['nuevo_rol'])) {
    $usuario_id = (int)$_POST['usuario_id'];
    $nuevo_rol  = (int)$_POST['nuevo_rol'];

    $sql = "UPDATE usuarios SET rol_id = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $nuevo_rol, $usuario_id);

    if ($stmt->execute()) {
        echo "✅ Rol actualizado con éxito.<br>";
    } else {
        echo "❌ Error al actualizar: " . $stmt->error;
    }
}

// Obtener lista de usuarios
$result = $conn->query("SELECT u.id, u.nombre, u.apellido, u.correo, r.nombre AS rol 
                        FROM usuarios u
                        JOIN roles r ON u.rol_id = r.id");
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel del Desarrollador - FusaTravel</title>
    <link href="css/style.css" rel="stylesheet">
</head>
<body>
    <div class="container py-5">
        <h1>👨‍💻 Panel del Desarrollador</h1>
        <p>Aquí puedes asignar roles a los usuarios.</p>

        <table border="1" cellpadding="10" cellspacing="0">
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Correo</th>
                <th>Rol actual</th>
                <th>Cambiar rol</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()) { ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><?= $row['nombre'] . " " . $row['apellido'] ?></td>
                <td><?= $row['correo'] ?></td>
                <td><?= $row['rol'] ?></td>
                <td>
                    <form method="post" action="">
                        <input type="hidden" name="usuario_id" value="<?= $row['id'] ?>">
                        <select name="nuevo_rol">
                            <option value="1">Turista</option>
                            <option value="2">Administrador</option>
                            <option value="3">Desarrollador</option>
                        </select>
                        <button type="submit">Actualizar</button>
                    </form>
                </td>
            </tr>
            <?php } ?>
        </table>
    </div>
</body>
</html>
